
        <?php
            echo 'Pas de voiture pour cette immatriculation';
        ?>
